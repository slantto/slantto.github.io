function r=deg2rad(d)
r=d*pi/180;
end