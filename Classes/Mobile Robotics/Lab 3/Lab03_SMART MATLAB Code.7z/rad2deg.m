function d=rad2deg(r)
d=r*180/pi;
end